package com.Honey;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.Honey.flight.acc;

/**
 * Servlet implementation class details
 */
public class details extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public details() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
		PrintWriter pw=response.getWriter();
		  response.setContentType("text/html");
 	   pw.print("<html>");
		pw.print("<head>");
		pw.print("<style>\r\n"
				+ "body {\r\n"
				+ "	background-image: url('tq.gif');\r\n"
				+ "	 background-attachment: fixed;\r\n"
				+ "  background-size:  80%100%;\r\n"
				+ "  background-repeat: no-repeat;\r\n"
				+ "}\r\n"
				+ "h1{\r\n"
				+ "color:orange;\r\n"
				+ "	font-size: 25px;\r\n"
				+ "text-align: center;\r\n"
				+ "text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				
				+"</style>"
				
				);

 	   pw.print("</head>");
 		HttpSession session=request.getSession();
 	   String n=(String)session.getAttribute("n"); 
      String id=(String) session.getAttribute("id");
      String nm=(String) session.getAttribute("nm");
      String sp=(String) session.getAttribute("sp");
      String ap=(String) session.getAttribute("ep");
      String d=(String) session.getAttribute("d");
      String a=(String) session.getAttribute("ap");
    
 	 
		pw.print("<body>");
		
		try {
		
			Connection con= acc.kk();
	        String sq="INSERT INTO `studentdb`.`a_book` (`Mail`, `Flight_id`, `Flight_name`, `StartPoint`, `EndPoint`, `Date`, `Airport`) "
	        		+ "VALUES ('"+n+"', '"+id+"', '"+nm+"', '"+sp+"', '"+ap+"', '"+d+"', '"+a+"')" +";  " ;
	        PreparedStatement st=con.prepareStatement(sq);
	      

       
       int row=st.executeUpdate();   
         if(row>=1) {
     		pw.print("<h1> Thank You !!! "
     				+ "<br><br>Flight Booked Sussefully");
     		
     	
          }
		}
		 catch(Exception e){
	    	  pw.println("<h1> Make Sure The Payment "+e);
		 }
      // pw.print(n+id+nm+d+ap+a+sp);
	
		pw.print("</body>");
      pw.print("</html>");
	 }
	
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
						}
				
	}
}
