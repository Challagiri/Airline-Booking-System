package com.Honey;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Honey.booking.acc;

/**
 * Servlet implementation class cancel
 */
public class cancel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cancel() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		
	int id=Integer.parseInt(request.getParameter("id"));	   
		try {
			Connection con= acc.kk();
		        
		        String sq="delete  from a_book  where id='"+id+"' ;" ;
		        //ResultSet rs = st.executeQuery("delete  from a_book  where id='"+id+"' ;");
		        PreparedStatement st=con.prepareStatement(sq);
		        int row=st.executeUpdate();   
		        if(row>=1) {
		        
		        	pw.print("Flight cancled");
		        	
		        }
		       	con.close();
		    			}
		    	       catch(Exception e){
		    	    	  pw.println(e);
		    	       }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
	}

}
