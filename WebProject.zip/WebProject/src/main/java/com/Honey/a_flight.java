package com.Honey;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import com.Honey.uflight.acc;

/**
 * Servlet implementation class a_flight
 */
public class a_flight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public a_flight() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//.request.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		   response.setContentType("text/html");
		pw.print("<html>");
		pw.print("<head>");
		pw.print("<title>"+"Flight's Details"+"</title>");
		pw.print("<style>\r\n"
				+ "body {\r\n"
				+ "	background-image: url('d.webp');\r\n"
				+ "	 background-attachment: fixed;\r\n"
				+ "  background-size:  100%120%;\r\n"
				+ "  background-repeat: no-repeat;\r\n"
				+ "}\r\n"
				+ "h1{\r\n"
				+ "color:orange;\r\n"
				+ "	font-size: 28px;\r\n"
				+ "text-align: center;\r\n"
				+ "text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"h4 {\r\n"
				+ "	font-size: 23px;\r\n"
				+"text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
				+ "text-align: right;\r\n"
				+ "}"
				+ "table, th, td {\r\n"
				+"font-size: 21px;\r\n"
				+"text-algin:center;\r\n"
			    +"border-collapse: collapse;\r\n"
				+ "border: 2px solid;\r\n"
				+ "}"
		
				+"form {\r\n"
				+ "    color:rgb(0, 0, 74);\r\n"
				+ "	text-align: center;\r\n"
				+"text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"</style>"
				
				);
		pw.print("</head>");
		pw.print("<body>");
		pw.print("<br><h1>\r\n"
				+ " <i>Flight's Details </i>\r\n"
				+ "</h1>");
		pw.print("<h4>\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Home.html\">Home</a>&nbsp  &nbsp\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Aboutus.html\"> About us</a> &nbsp\r\n"
				+ "</h4>");
	pw.print("<h3>\r\n"
			+"<form>\r\n"
			+ " From * City: <input type=\"text\" name=\"fc\">\r\n"
			+ "        &nbsp    To * City: <input type=\"text\" name=\"tc\">"
			+" &nbsp &nbsp <input type=submit formaction=\"http://localhost:8080/WebProject/a_searchf\" value=\"Search\"></form>\r\n"
			+ "</h3>");
	
		pw.print("<br><br><br> <table>");
		try {
			Connection con= acc.kk();
		        Statement st = con.createStatement();
		        ResultSet rs = st.executeQuery("select * from a_flight ;");
		        ResultSetMetaData rsmd= rs.getMetaData();
		    
				
		        pw.print("<tr>");
		        pw.print("<th>"+rsmd.getColumnName(1) + "</th>  " + "<th>  "+ rsmd.getColumnName(2) + "</th>  " +"<th>  "+
		                rsmd.getColumnName(3)+"</th>  "+"<th>  "+rsmd.getColumnName(4)+"</th>  "+"<th>  "+rsmd.getColumnName(5)+"</th>  "+"<th>  "+ rsmd.getColumnName(6)+ " "
		        		+"</th>  "+"<th>  "+ rsmd.getColumnName(7)+ "</th>  "+"<th>  "+ rsmd.getColumnName(8)+ "</th>  "+"<th>  "
		                + rsmd.getColumnName(9)+"</th>"+"<th>"+rsmd.getColumnName(10)+"</th>");
		        pw.print("</tr>");
		        while (rs.next()) {
		        pw.println("<tr>");
		        
		            pw.println( "<td>"+rs.getString("flight_id") + "</td>  "+"<td>  " +rs.getString("flight_name")+ "</td>  "+"<td>  "+rs.getString("Startpoint")+ "</td>  "+"<td>  "
		               +rs.getString("Endpoint")+ "</td>  "+"<td>  "+rs.getString("time")+ "</td>  "+"<td>  "+rs.getDate("date")+  "</td>  "+"<td>  "
		            		+rs.getString("time_dur")+  "</td>  "+"<td>  " +rs.getString("Airport")+  "</td>  "+"<td>  "+rs.getInt("price")+ " INR</td>"
		            		+"<td>"+"<form><input  name=id value='"+rs.getString(1)+"' hidden readonly>" 
		            				+ "<input type=submit formaction=http://localhost:8080/WebProject/booking value=Book></form>"+
		            		"</td>");
		        
		        
		   pw.println("</tr>");
		  
		   
		        }
	           
	            	con.close();
			}
	       catch(Exception e){
	    	  pw.println(e);
	       }
		pw.print("</table>");

		pw.print("</body>");
		pw.print("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
