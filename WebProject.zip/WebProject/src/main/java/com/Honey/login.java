package com.Honey;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String mail=request.getParameter("mail");
		String pwd=request.getParameter("pwd");
		PrintWriter pw=response.getWriter();
		 HttpSession session=request.getSession();  
		try {
			Connection con= acc.kk();
		        Statement st = con.createStatement();
		        ResultSet rs = st.executeQuery("select * from a_user where mail='" + mail + "' and pwd='" + pwd + "';");
		        response.setContentType("text/html");
		    	pw.print("<html>");
		    	pw.print("<head>");
		        pw.print("<style >\r\n"
		        		+ "body{\r\n"
		        		+ " background-image: url('us1.jpg');\r\n"
		        		+ " 	background-attachment: fixed;\r\n"
		        		+ "  background-size: 100%120%;\r\n"
		        		+" }"
		        		+ "h1{\r\n"
		        		+ "color:red;\r\n"
		        		+ "	fon+t-size: 35px;\r\n"
		        		+ "text-align: center;\r\n"
		        		+"text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
		        		+ "}"
		        		+"div {\r\n"
		        		+ "	font-size: 20px;\r\n"
		        		+ "text-align: right;\r\n"
		        		+ "}"
		        		+ "p1{\r\n"
		        		+ "font-size: 20px;\r\n"
		        		+"color: red;\r\n"
		        		+ "  text-align: center;"
		        		
		        		+ "</style>");
		    	pw.print("<title> Login Servlet </title>");
		    	pw.print("</head>");
		    	pw.print("<body>");
		    	pw.print("<h1>");
	            if (rs.next()) {
	            		if(mail.equals("Admin@air.com")&& pwd.equals("Ad123")) {
	                pw.println( "\n" + "<i> Welcome Back  " + rs.getString("Name")+"!</i>");
	                pw.print("<div>\r\n"
	        	          
	        				+ "<br> <a href=\"http://localhost:8080/WebProject/login.html?\"> Log Out</a> &nbsp   &nbsp\r\n"+"<br><br>"
	                		+ "<a href=\"http://localhost:8080/WebProject/Home.html\">Home</a> &nbsp   &nbsp"
	                		+ "<a href=\"http://localhost:8080/WebProject/flight.html\">Add Flight</a> &nbsp   &nbsp"
	                		+ "<a href=\"http://localhost:8080/WebProject/showflight\" >Flight Report </a> &nbsp   &nbsp"
	                		+ "</div>");
	                
	            	}
	            		else {
	            	
	            		        //session.setAttribute("uname",rs.getString(1));  
	            			   pw.println( "\n"+ "<i> Hello  " + rs.getString("Name") +" !</i>");
	            			   pw.print("  <div>\r\n"
	         	        	      
	         	        				+ " <br> <a href=\"http://localhost:8080/WebProject/login.html?\"> Log Out</a> &nbsp   &nbsp\r\n"+"<br><br>"
	         	                		+ "<a href=\"http://localhost:8080/WebProject/Home.html\">Home</a> &nbsp   &nbsp"
	         	                		+ "<a href=\"http://localhost:8080/WebProject/a_flight\" >Book A Flight </a> &nbsp   &nbsp"
	         	                		+ "<a href=\"http://localhost:8080/WebProject/recent\" >Recent Booking </a> &nbsp   &nbsp"
	         	                		+ "</div>");
	            			   session.setAttribute("n", mail);
	            			   session.setAttribute("nm", rs.getString("Name"));
	            		}
	            		
	            
	            }
	            else {
	           //request.setAttribute("error","Invalid Username or Password");
	            RequestDispatcher rd=request.getRequestDispatcher("/login.html?");   
	            pw.print("<p1>\r\n"
	            		+ "Invalid Password\r\n"
	            		+ "</p1>");
	            rd.include(request, response);
	            }
	           
	            	con.close();
			}
	       catch(Exception e){
	    	  pw.println(e);
	       }
	
		pw.print("</h1>");
		pw.print("</body>");
		pw.print("</html>");

	
	}
class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
		
	}

}
