package com.Honey;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



/**
 * Servlet implementation class flight
 */
public class flight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public flight() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//PrintWriter pw=response.getWriter();
	
				}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter pw=response.getWriter();
		  response.setContentType("text/html");
   	   pw.print("<html>");
  		pw.print("<head>");
  		pw.print("<style>\r\n"
				+ "h1{\r\n"
				+ "color:orange;\r\n"
				+ "	font-size: 25px;\r\n"
				+ "text-align: left;\r\n"
				+ "text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"</style>"
				
				);

   	   pw.print("</head>");
				
  		pw.print("<body>");
  		 RequestDispatcher rd=request.getRequestDispatcher("/flight.html"); 
    	
		try {
		
			Connection con= acc.kk();
	        String sq="insert into a_flight values (?,?,?,?,?,?,?,?,?,?) ;";
	        PreparedStatement st=con.prepareStatement(sq);
	        String fn=request.getParameter("fn");
			String fnm=request.getParameter("fnm");
			String fc=request.getParameter("fc");
			String tc=request.getParameter("tc");
			String t=request.getParameter("t");
			String d=request.getParameter("d");
			String dt=request.getParameter("dt");
			String ap=request.getParameter("ap");
			String tp=request.getParameter("tp");
			String bk=request.getParameter("bk");
			
	
			st.setString(1,fn);
	        st.setString(2,fnm);
            st.setString(3,fc);
            st.setString(4,tc);
            st.setString(5,t);
            st.setString(6,d);
            st.setString(7,dt);
            st.setString(8,ap);
            st.setString(9,tp);
            st.setString(10,bk);
            
	       
            int row=st.executeUpdate();
           if(row>=1) {
  
       		pw.print("<h1> Hello "
       				+ "<br><br> Data Registed Sussefully");
       	
            }
		}
		 catch(Exception e){
	    	  pw.println("<h1> Fill The details ");
		 }
		 rd.include(request, response);
		pw.print("</body>");
        pw.print("</html>");
        	
	}
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
		}

}
