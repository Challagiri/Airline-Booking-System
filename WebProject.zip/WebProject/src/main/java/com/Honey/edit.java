package com.Honey;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.Honey.flight.acc;

/**
 * Servlet implementation class edit
 */
public class edit extends HttpServlet{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		
		try {
		
			Connection con= acc.kk();
			 String fn=request.getParameter("fn");
				String fnm=request.getParameter("fnm");
				String fc=request.getParameter("fc");
				String tc=request.getParameter("tc");
				String t=request.getParameter("t");
				String d=request.getParameter("d");
				String dt=request.getParameter("dt");
				String ap=request.getParameter("ap");
				String tp=request.getParameter("tp");
				//String bk=request.getParameter("bk");
				
	        String sq="update a_flight set Time='"+t+"',flight_name='"+fnm+"',"	+" startpoint='"+fc+"',endpoint='"+tc+"',"
	        		+ "date='"+d+"',Airport='"+ap+"',Price='"+tp+"',time_dur='"+dt+"' where Flight_Id='"+fn+"';";
	        PreparedStatement st=con.prepareStatement(sq);
	        response.setContentType("text/html");
     	   pw.print("<html>");
    		pw.print("<head>");
    		
    		pw.print("<style>\r\n"
    				+ "body {\r\n"
    				+ "	background-image: url('sky.jpg');\r\n"
    				+ "	 background-attachment: fixed;\r\n"
    				+ "  background-size:  100%120%;\r\n"
    				+ "  background-repeat: no-repeat;\r\n"
    				+ "}\r\n"
    				+ "h1{\r\n"
    				+ "color:red;\r\n"
    				+ "	font-size: 25px;\r\n"
    				+ "text-align: center;\r\n"
    				+ "text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
    				+ "}"
    				+"</style>"
    				
    				);
     
        	   pw.print("</head>");
        		pw.print("<body>"); 
        		
            int row=st.executeUpdate();
           if(row==1) {
       	
       		pw.print("<h1> Hello "
       				+ "<br><br> Details Edited Sussefully");
       	
            }
           else
   			pw.print("<br><br> <h1>Fill The Details Properely ");
		}
		 catch(Exception e){
	    	  pw.println(e);
		 }
		
		pw.print("</body>");
        pw.print("</html>");
        	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	   }
	
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
		}
        	

}
