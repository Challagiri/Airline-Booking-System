package com.Honey;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.Honey.uflight.acc;

/**
 * Servlet implementation class booking
 */
public class booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public booking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		   response.setContentType("text/html");
		pw.print("<html>");
		pw.print("<head>");
		pw.print("<title>"+"Book A Flight"+"</title>");
		pw.print("<style>\r\n"
				+ "body {\r\n"
				+ "	background-image: url('ho4.jpg');\r\n"
				+ "	 background-attachment: fixed;\r\n"
				+ "  background-size:  100%110%;\r\n"
				+ "  background-repeat: no-repeat;\r\n"
				+ "}\r\n"
				+ "h1{\r\n"
				+ "color:orange;\r\n"
				+ "	font-size: 28px;\r\n"
				+ "text-align: center;\r\n"
				+ "text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"h4 {\r\n"
				+ "	font-size: 23px;\r\n"
				+"text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
				+ "text-align: right;\r\n"
				+ "}"
				+ "table, th, td {\r\n"
				+"font-size: 21px;\r\n"
				+"text-algin:center;\r\n"
			    +"border-collapse: collapse;\r\n"
				+ "border: 2px solid;\r\n"
				+ "}"
				+"h5{\r\n"
				+"text-align:center\r\n"
				+ "}"
		
				+"form {\r\n"
				+ "    color:rgb(0, 0, 74);\r\n"
				+ "	text-align: center;\r\n"
				+"text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"</style>"
				
				);
		pw.print("</head>");
		pw.print("<body>");
		pw.print("<h1>\r\n"
				+ " <i>Booking Flight </i> \r\n"
				+ "</h1>");
		pw.print("<h4>\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Home.html\">Home</a>&nbsp  &nbsp\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Aboutus.html\"> About us</a> &nbsp\r\n"
				+ "</h4>");
		pw.print("</table>");
		
		   HttpSession session=request.getSession(); 
		   
	        String n=(String)session.getAttribute("n");  
		pw.print("<br> <table>");
		try {
			Connection con= acc.kk();
		        Statement st = con.createStatement();
		        ResultSet rs = st.executeQuery("select * from a_user  where mail='"+n+"' ;");
		        ResultSetMetaData rsmd= rs.getMetaData();

		        pw.print("<tr>");
		        pw.print("<th> Passenger Details </th>");
		        pw.print("</tr>");
		        while (rs.next()) {
		        pw.println("<tr>");
		        
		            pw.println( "<td> "+rsmd.getColumnName(1) + " :  "+rs.getString("Mail") +  "<br><br>    "+rsmd.getColumnName(3) +" :   "+rs.getString("name")+  " &nbsp &nbsp "+
		            " <br><br>   "+rsmd.getColumnName(4)+"  :  " +rs.getString("Ph Num")+ "<br><br>   "+rsmd.getColumnName(5) +" :   "+rs.getString("Address")+"<br><br>  </td>");
		        
		   pw.println("</tr>");
		
		        }
	           
	            	con.close();
			}
	       catch(Exception e){
	    	  pw.println(e);
	       }
		
		pw.print("</table>");
		
	
		pw.print("<br><br><br><br> <table>");
		String id=request.getParameter("id");
	   
		try {
			Connection con= acc.kk();
		        Statement st = con.createStatement();
		        ResultSet rs = st.executeQuery("select * from a_flight  where flight_id='"+id+"' ;");
		        ResultSetMetaData rsmd= rs.getMetaData();

		        pw.print("<tr>");
		        pw.print("<th> Confirm Details </th>");
		        pw.print("</tr>");
		        while (rs.next()) {
		        pw.println("<tr>");
		        
		            pw.println( "<td> "+rsmd.getColumnName(1) + " :  "+rs.getString("flight_id") + "<br><br>   "+rsmd.getColumnName(2) + " :  " +rs.getString("flight_name")+ "<br><br>   "+rsmd.getColumnName(3) +" :   "+rs.getString("Startpoint")+  " &nbsp &nbsp "+
		            " <br><br>   "+rsmd.getColumnName(4)+"  :  " +rs.getString("Endpoint")+ "  <br><br>   "+rsmd.getColumnName(5) +" :  "+rs.getString("time")+ "</td>"
		            	+"<td>  "+rsmd.getColumnName(6) +" :   "+rs.getDate("date")+  "<br><br>   "+rsmd.getColumnName(7) +" :  "+rs.getString("time_dur")+  "<br><br>  "+rsmd.getColumnName(8) +"  :  " +rs.getString("Airport")+  "<br><br>   "
		            			+ " "+rsmd.getColumnName(9) +"  :  "+rs.getInt("price")+ " INR </td>"
		            			);
		          
		            session.setAttribute("id", rs.getString(1));
		 		   session.setAttribute("nm", rs.getString(2));
		 		   session.setAttribute("sp", rs.getString(3));
		 		   session.setAttribute("ep", rs.getString(4));
		 		   session.setAttribute("d", rs.getString(6));
		 		   session.setAttribute("ap", rs.getString(8));
		            
		   pw.println("</tr>");
		   pw.print("<th>"
	            	+"<form>"
				   +" No.of Passengers :<input type=text  name=pag> <br><br>"
	            	+ "<input  name=pr value='"+rs.getInt(9)+"' hidden readonly>"
	            	+"<input type=submit formaction=http://localhost:8080/WebProject/pay  value=\"Make A Payment\">"
	            	+ "</form> </th>");
		 
		        }
	           
	            	con.close();
			}
	       catch(Exception e){
	    	  pw.println(e);
	       }
		
		
		
		pw.print("</body>");
		pw.print("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
	
}
}