package com.Honey;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



/**
 * Servlet implementation class signup
 */
public class signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter pw=response.getWriter();
        response.setContentType("text/html");
    	pw.print("<html>");
    	pw.print("<head>");
        pw.print("<style >\r\n"
        		+"body{\r\n"
        		+ " background-image: url('sky.jpg');\r\n"
        		+ " 	 background-attachment: fixed;\r\n"
        		+ "  background-size:  100%120%;\r\n"
        		+ "  background-repeat: no-repeat;\r\n"
        		+ "}"
        		+"h2{\r\n"
        		+"color:green;\r\n"
        		+ "text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
        		+ "font-size: 30px;\r\n"
        		+ "text-align: center;\r\n"
        		+ "}"
        		+"p{\r\n"
        		+ "color;green;\r\n"
        		+ " font-size: 30px;\r\n"
        		+ " text-align: center;\r\n"
        		+ " }"
        		+ "</style>");
    	pw.print("<title> Sign up Servlet </title>");
    	pw.print("</head>");
    	pw.print("<body>");
    	 RequestDispatcher rd=request.getRequestDispatcher("/signup.html"); 
    	 rd.include(request, response);
		try {
		
			Connection con= acc.kk();
	        String sq="insert into a_user values (?,?,?,?,?) ;";
	        PreparedStatement st=con.prepareStatement(sq);
	        String mid=request.getParameter("mid");
			String pwd=request.getParameter("pwd");
			String name=request.getParameter("name");
			String num=request.getParameter("num");
			String add=request.getParameter("add");
			
			st.setString(1,mid);
	        st.setString(2,pwd);
            st.setString(3,name);
            st.setString(4,num);
            st.setString(5,add);
            
            int row=st.executeUpdate();

            if(row>=1) {
            	
            	 pw.print("<h2> Registed Sussefully"
            	 		+ "<br> <p>Please login Through login page");
            }
           
       
	}
		 catch(Exception e){
			 pw.print("<h2>Fill the Details");
		 }
		pw.print("</body>");
		pw.print("</html>");
		
	}
	class acc{
		protected static Connection kk() throws SQLException, ClassNotFoundException {
			        Class.forName("com.mysql.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Tejasree@1");   
				return con;
			}
		}
	
}
