package com.Honey;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class pay
 */
public class pay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		  response.setContentType("text/html");
		pw.print("<html>");
		pw.print("<head>");
		pw.print("<title>"+"payment"+"</title>");
		pw.print("<style>\r\n"
				+ "body {\r\n"
				+ "	background-image: url('ho4.jpg');\r\n"
				+ "	 background-attachment: fixed;\r\n"
				+ "  background-size:  100%110%;\r\n"
				+ "  background-repeat: no-repeat;\r\n"
				+ "}\r\n"
				+ "h1{\r\n"
				+ "color:orange;\r\n"
				+ "	font-size: 28px;\r\n"
				+ "text-align: center;\r\n"
				+ "text-shadow: 2px 2px 4px #ff4000;\r\n"
				+ "}"
				+"h4 {\r\n"
				+ "	font-size: 23px;\r\n"
				+"text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
				+ "text-align: right;\r\n"
				+ "}"
				+ "table, th, td {\r\n"
				+"font-size: 21px;\r\n"
				+"text-algin:center;\r\n"
			    +"border-collapse: collapse;\r\n"
				+ "border: 2px solid;\r\n"
				+ "}"
				+"h2{\r\n"
				+"text-align:center\r\n"
				+ "font-size: 23px;\r\n"
				+"text-shadow: 4px 4px 6px rgb(215, 220, 253);\r\n"
				+ "}"
				+"form {\r\n"
				+"font-size:20px\r\n"
				+ "    color:rgb(0, 0, 74);\r\n"
				+ "	text-align: center;\r\n"
				+"}"
				+"</style>");
		pw.print("</head>");
		pw.print("<body>");
		HttpSession session=request.getSession();
		   int pag=Integer.parseInt(request.getParameter("pag"));
		  
		
		pw.print("<br><h1>\r\n"
				+ " <i>Payment Method</i> \r\n"
				+ "</h1>");
		pw.print("<h4>\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Home.html\">Home</a>&nbsp  &nbsp\r\n"
				+ "<a href=\"http://localhost:8080/WebProject/Aboutus.html\"> About us</a> &nbsp\r\n"
				+ "</h4>");
		
		int p=Integer.parseInt(request.getParameter("pag"));
		int pr=Integer.parseInt(request.getParameter("pr"));
		int tp=(int) ((int) p*pr*(0.7));
		  session.setAttribute("p", p);
		if(p>=1) {
		pw.print("<h2>"
				+ " Price :  " +pr+" INR&nbsp <br><br>"	
				+ "Total Price With Offer :  "+tp+" INR<br><br>"
						+ "The No.of Passengers is : "+ pag
						+ "</h2>");
		
		pw.print("<br> <table>"); 
		  pw.print("<tr>");
	        pw.print("<th> Debit/Credit Card Details </th>");
	        pw.print("</tr>");
	   
	        pw.println("<tr>"
	        		+ "<form method=post>");
	        
	            pw.println( "<td> Card.No : <input type=text name=cn > <br><br>"
	            		+ " Card Holder Name : <input type=text name=chn ><br><br>" 
	            		+ "  Month / Year : <input type=text name=my ><br><br> "
	            		+ " CVV : <input type=text name=cvv ><br></td>");
	        
	   pw.println("</tr>"+ " </form>");
		pw.print("</table>");
		pw.print("<br><br><form method=post>"
				+ "<input type=submit formaction=http://localhost:8080/WebProject/details value=\"Payment and Book\" >"
				+ " or <input type=reset value=Cancel>"
				+ "</from>");
	}
		else
			pw.print("<h2>Enter the Passenger's Number");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
